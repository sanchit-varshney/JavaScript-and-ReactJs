import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        I have attended the 7 days free bootcamp on Web development with Javascript & React.js conducted by Shape AI
      </p>
    </div>
  );
}

export default Note;
